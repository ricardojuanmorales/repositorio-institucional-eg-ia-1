# Repositorio Institucional EG-IA · candidato G2

Modo: INTEGRATE
Framework: 5.2.0

## Problema
Integrar de forma reversible el repositorio institucional EG-IA v0.3 en Framework v5.2 sin pérdida de identidad ni procedencia de los registros CAT/FIC/MAT/CUR.

## Propósito
Preparar contratos portables nativos v5.2 y extensiones verificables para una futura migración integral a staging, sujeta a gate humano independiente.

## Continuidad
Solicitar ratificación de G2-R2 y, separadamente, autorización limitada de G3; comprobar N4 de autonomía con evidencias, runtime, restauración y límites de control humano. No modificar GitHub ni ejecutar INTEGRATE por esta decisión.
